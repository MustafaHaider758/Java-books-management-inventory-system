class DVD {
    private String itemId;
    private String title;
    private String director;
    private double price;
    private int quantityInStock;

    public DVD(String itemId, String title, String director, double price, int quantityInStock) {
        this.itemId = itemId;
        this.title = title;
        this.director = director;
        this.price = price;
        this.quantityInStock = quantityInStock;
    }

    
    public String getItemId() {
        return itemId;
    }
    
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantityInStock() {
        return quantityInStock;
    }

    public void setQuantityInStock(int quantityInStock) {
        this.quantityInStock = quantityInStock;
    }

    
}