class Member {
    private String memberId=null;
    private String name;
   private double totalSpent;

    public Member(String memberId, String name, double totalSpent) {
        this.memberId = memberId;
        this.name = name;
        this.totalSpent=0.0;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
public double getTotalSpent() {
        return totalSpent;
    }

    public void addToTotalSpent(double amount) {
        totalSpent += amount;
    }
   
  
    
    }

    
