class PremiumMember {
    private String memberId;
    private String name;
    private double totalSpent;
    private double monthlyFee;
    private String paymentMethod;
    private boolean isMonthlyFeePaid;

    public PremiumMember(String memberId, String name, double totalSpent, double monthlyFee, String paymentMethod, boolean isMonthlyFeePaid) {
        this.memberId = memberId;
        this.name = name;
        this.totalSpent = totalSpent;
        this.monthlyFee = monthlyFee;
        this.paymentMethod = paymentMethod;
        this.isMonthlyFeePaid = isMonthlyFeePaid;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getTotalSpent() {
        return totalSpent;
    }

    public void setTotalSpent(double totalSpent) {
        this.totalSpent = totalSpent;
    }

    public double getMonthlyFee() {
        return monthlyFee;
    }

    public void setMonthlyFee(double monthlyFee) {
        this.monthlyFee = monthlyFee;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public boolean isIsMonthlyFeePaid() {
        return isMonthlyFeePaid;
    }

    public void setIsMonthlyFeePaid(boolean isMonthlyFeePaid) {
        this.isMonthlyFeePaid = isMonthlyFeePaid;
    }

   
}