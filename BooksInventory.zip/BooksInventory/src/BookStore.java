
//Library.java
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class BookStore {
  private ArrayList < Book > books;
  private ArrayList < CD > cds;
  private ArrayList<DVD> dvds;
  private ArrayList<Member> members;
  private ArrayList<PremiumMember> premiumMembers;
  private Map<String, Integer> inventoryCounts;

    public BookStore(ArrayList<Book> books, ArrayList<CD> cds, ArrayList<DVD> dvds, ArrayList<Member> members, ArrayList<PremiumMember> premiumMembers) {
        this.books = books;
        this.cds = cds;
        this.dvds = dvds;
        this.members = members;
        this.premiumMembers = premiumMembers;
    }

    public BookStore(Map<String, Integer> inventoryCounts) {
        this.inventoryCounts = inventoryCounts;
    }
   
//Add functions
    
  public void addBook(Book book) {
    books.add(book);
  }

  public void addCD(CD cd) {
        cds.add(cd);
    }

    public void addDVD(DVD dvd) {
        dvds.add(dvd);
    }

    public void registerMember(Member member) {
       members.add(member);
    }

    public void registerPremiumMember(PremiumMember premiumMember) {
        premiumMembers.add(premiumMember);
    }
    
    
    //remove functions
  public void removeBook(Book book) {
    books.remove(book);
  }

  public void removeCD(CD cd) {
        cds.remove(cd);
    }

    public void removeDVD(DVD dvd) {
        dvds.remove(dvd);
    }

    public void removeMember(Member member) {
       members.remove(member);
    }

    public void removePremiumMember(PremiumMember premiumMember) {
        premiumMembers.remove(premiumMember); 
}

    //Getters
 
    public ArrayList<Book> getBooks() {
        return books;
    }

    public ArrayList<CD> getCds() {
        return cds;
    }

    public ArrayList<DVD> getDvds() {
        return dvds;
    }

    public ArrayList<Member> getMembers() {
        return members;
    }

    public ArrayList<PremiumMember> getPremiumMembers() {
        return premiumMembers;
    }
    
    

    

    // Other methods

    public void completePurchase(Member member, ArrayList<String> itemIds) {
        double totalPrice = calculateTotalPrice(itemIds);

        // Check if the member has enough total spent to make the purchase
        if (member.getTotalSpent() >= totalPrice) {
            // Update member's total spent
            member.addToTotalSpent(totalPrice);

            // Deduct items from the inventory
            for (String itemId : itemIds) {
                if (inventoryCounts.containsKey(itemId)) {
                    int currentCount = inventoryCounts.get(itemId);
                    if (currentCount > 0) {
                        inventoryCounts.put(itemId, currentCount - 1);
                    } else {
                        System.out.println("Item with ID " + itemId + " is out of stock.");
                    }
                } else {
                    System.out.println("Item with ID " + itemId + " does not exist in the inventory.");
                }
            }

            System.out.println("Purchase completed successfully.");
        } else {
            System.out.println("Insufficient total spent. Purchase cannot be completed.");
        }
    }

    // Other methods

   private double calculateTotalPrice(ArrayList<String> itemIds) {
    double totalPrice = 0.0;

    for (String itemId : itemIds) {
        double itemPrice = 0.0;

        // Retrieve the item details based on the item ID
        // Assuming inventoryCDs, inventoryBooks, and inventoryDVDs are ArrayLists in the Bookstore class
        for (CD cd : cds) {
            if (cd.getItemId().equals(itemId)) {
                itemPrice = cd.getPrice() * cd.getQuantityInStock();
                break;
            }
        }

        for (Book book : books) {
            if (book.getItemId().equals(itemId)) {
                itemPrice = book.getPrice() * book.getQuantityInStock();
                break;
            }
        }

        for (DVD dvd : dvds) {
            if (dvd.getItemId().equals(itemId)) {
                itemPrice = dvd.getPrice() * dvd.getQuantityInStock();
                break;
            }
        }

        // Add the item's total price to the total
        totalPrice += itemPrice;
    }

    return totalPrice;
}

    public Member getMemberById(Member memberId) {
        for (Member member : members) {
            if (member.getMemberId().equals(memberId)) {
                return member;
            }
        }
        return null;  // Return null if member not found
    }

}

