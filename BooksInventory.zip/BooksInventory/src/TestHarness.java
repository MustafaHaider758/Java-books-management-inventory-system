

import java.util.ArrayList;
import java.util.Scanner;

public class TestHarness {

    public static void main(String[] args) {
        ArrayList<Book> bookList = new ArrayList<>();
        ArrayList<CD> cdList = new ArrayList<>();
        ArrayList<DVD> dvdList = new ArrayList<>();
        ArrayList<Member> memberList = new ArrayList<>();
        ArrayList<PremiumMember> premiumMemberList = new ArrayList<>();

        // Populate the lists with appropriate data
        // Create the BookStore instance with the provided ArrayLists
        BookStore bookstore = new BookStore(bookList, cdList, dvdList, memberList, premiumMemberList);

        Scanner scanner = new Scanner(System.in);
        int choice;

        while (true) {
            System.out.println("\n===== Main Menu =====");
            System.out.println("1. Add a Book");
            System.out.println("2. Add a CD");
            System.out.println("3. Add a DVD");
            System.out.println("4. Add a Member");
            System.out.println("5. Add a Premium Member");
            System.out.println("6. Remove a Book");
            System.out.println("7. Make a purchase");
            System.out.println("8. Show all inventory");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();

            switch (choice) {
                case 1:
System.out.print("Enter itemid: ");
                    String itemid = scanner.nextLine();
                    System.out.print("Enter title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter author: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter price: ");
                    double price = scanner.nextDouble();
                    System.out.print("Enter quantity: ");
                    int quantity = scanner.nextInt();
                    Book newBook = new Book(itemid, title, author, price, quantity);
                    bookstore.addBook(newBook);
                    break;
                case 2:
System.out.print("Enter itemid: ");
                    String cditemid = scanner.nextLine();
                    System.out.print("Enter CD title: ");
                    String cdTitle = scanner.nextLine();
                    System.out.print("Enter CD artist: ");
                    String cdArtist = scanner.nextLine();
                    System.out.print("Enter CD price: ");
                    double cdPrice = scanner.nextDouble();
                    System.out.print("Enter CD quantity: ");
                    int cdQuantity = scanner.nextInt();
                    CD newCD = new CD(cditemid, cdTitle, cdArtist, cdPrice, cdQuantity);
                    bookstore.addCD(newCD);
                    break;

                case 3:
                    System.out.print("Enter itemid: ");
                    String dvditemid = scanner.nextLine();
                    System.out.print("Enter DVD title: ");
                    String dvdTitle = scanner.nextLine();
                    System.out.print("Enter DVD director: ");
                    String dvdDirector = scanner.nextLine();
                    System.out.print("Enter DVD price: ");
                    double dvdPrice = scanner.nextDouble();
                    System.out.print("Enter DVD quantity: ");
                    int dvdQuantity = scanner.nextInt();
                    DVD newDVD = new DVD(dvditemid, dvdTitle, dvdDirector, dvdPrice, dvdQuantity);
                    bookstore.addDVD(newDVD);
                    break;
                case 4:
    
    System.out.println("Adding a new member:");
    System.out.print("Enter member ID: ");
    String memberId = scanner.nextLine();
    System.out.print("Enter member name: ");
    String memberName = scanner.nextLine();

    // Create a new Member instance
    Member newMember = new Member(memberId,memberName,0.0);
    
    // Set the member's attributes
    
    // Initialize the total spent to 0.0

    // Register the new member in the bookstore
    bookstore.registerMember(newMember);

    System.out.println("New member added successfully.");
 

    break;

                    case 5:
                   
    System.out.print("Enter premium member ID: ");
    String premiumMemberId = scanner.nextLine();
    System.out.print("Enter premium member name: ");
    String premiumMemberName = scanner.nextLine();
    System.out.print("Enter monthly fee: ");
    double monthlyFee = scanner.nextDouble();
    scanner.nextLine();  // Consume the newline character
    System.out.print("Enter payment method: ");
    String paymentMethod = scanner.nextLine();

    // Assuming isMonthlyFeePaid should be initially false
    PremiumMember newPremiumMember = new PremiumMember(premiumMemberId, premiumMemberName, 0.0, monthlyFee, paymentMethod, false);
    bookstore.registerPremiumMember(newPremiumMember);


                    break;
                    case 6:
                    System.out.print("Enter title of the book to remove: ");
                String bookTitleToRemove = scanner.nextLine();
                    break;
                    case 7:
    System.out.println("Making a purchase:");
    System.out.print("Enter your member ID: ");
 

    // Assuming we have a method to retrieve a member by their ID
    Member member = bookstore.getMemberById(null);

    if (member != null) {
        // Display available items for purchase
        System.out.println("Available items:");
        // Display available CDs
        for (CD cd : cdList) {
            System.out.println("CD: " + cd.getTitle() + " (ID: " + cd.getItemId() + ") - Price: $" + cd.getPrice());
        }
        // Display available Books
        for (Book book : bookList) {
            System.out.println("Book: " + book.getTitle() + " (ID: " + book.getItemId() + ") - Price: $" + book.getPrice());
        }
        // Display available DVDs
        for (DVD dvd : dvdList) {
            System.out.println("DVD: " + dvd.getTitle() + " (ID: " + dvd.getItemId() + ") - Price: $" + dvd.getPrice());
        }

        System.out.print("Enter item ID to purchase (or 'done' to finish): ");
        String itemToBuyId = scanner.nextLine();

        ArrayList<String> itemsToBuy = new ArrayList<>();
        while (!itemToBuyId.equals("done")) {
            itemsToBuy.add(itemToBuyId);
            System.out.print("Enter another item ID (or 'done' to finish): ");
            itemToBuyId = scanner.nextLine();
        }

        bookstore.completePurchase(member, itemsToBuy);
    } else {
        System.out.println("Member with ID " +  " not found.");
    }

    break;

                case 8:
                    System.out.println("Books in the library:");
                for (Book book : bookstore.getBooks()) {
                    System.out.println(book.getTitle() + " by " + book.getAuthor());
                }
                    break;
                case 9:
                    // Exit
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
